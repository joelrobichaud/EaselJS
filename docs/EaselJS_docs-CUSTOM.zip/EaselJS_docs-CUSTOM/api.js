YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "AlphaMapFilter",
        "AlphaMaskFilter",
        "Bitmap",
        "BitmapAnimation",
        "BoxBlurFilter",
        "ColorFilter",
        "ColorMatrix",
        "ColorMatrixFilter",
        "Command",
        "Container",
        "DOMElement",
        "DisplayObject",
        "Event",
        "EventDispatcher",
        "Filter",
        "Graphics",
        "Keyboard",
        "KeyboardEvent",
        "Matrix2D",
        "MouseEvent",
        "MovieClip",
        "MovieClipPlugin",
        "NativeEvent",
        "Point",
        "Rectangle",
        "Shadow",
        "Shape",
        "SpriteSheet",
        "SpriteSheetBuilder",
        "SpriteSheetUtils",
        "Stage",
        "Text",
        "Ticker",
        "Timer",
        "TimerEvent",
        "Touch",
        "UID"
    ],
    "modules": [
        "EaselJS"
    ],
    "allModules": [
        {
            "displayName": "EaselJS",
            "name": "EaselJS",
            "description": "The EaselJS Javascript library provides a retained graphics mode for canvas\nincluding a full, hierarchical display list, a core interaction model, and\nhelper classes to make working with 2D graphics in Canvas much easier."
        }
    ]
} };
});